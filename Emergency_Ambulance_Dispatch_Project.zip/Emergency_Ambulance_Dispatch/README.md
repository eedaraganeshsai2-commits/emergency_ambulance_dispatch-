# Emergency Ambulance Dispatch System

A beginner-friendly Java Swing mini-project for the OOP course. It simulates emergency-call registration, severity-based queueing, nearest-free-ambulance selection, hospital suggestion, ambulance status, and dispatch history.

## Requirements
- JDK 17 or later (JDK 8+ may also work)
- VS Code with the Extension Pack for Java (recommended)

## Run in VS Code
1. Extract this project ZIP.
2. Open the `Emergency_Ambulance_Dispatch` folder in VS Code.
3. Open `src/ambulance/App.java`.
4. Click **Run** above `main`, or compile/run from a terminal:

```bash
javac -d out src/ambulance/model/*.java src/ambulance/exception/*.java src/ambulance/service/*.java src/ambulance/ui/*.java src/ambulance/App.java
java -cp out ambulance.App
```

Run commands from the project root folder.

## Features
- Swing GUI with patient, X/Y coordinates, severity and action buttons
- Finds the nearest available ambulance using Euclidean distance
- Severity-based `PriorityQueue` (severity 5 is critical)
- `ArrayList`, `HashMap`, and `Iterator`
- Custom `NoAmbulanceAvailableException`
- `try-catch-finally` validation
- CSV file handling in `data/dispatch_history.csv`
- Background monitoring thread
- Four user-defined packages: `ambulance.model`, `ambulance.service`, `ambulance.exception`, `ambulance.ui`

## Notes
This is an educational simulation using simple X/Y coordinates, not a real emergency dispatch service. Ambulance locations are fixed for demonstration; dispatch marks a vehicle busy until the Release Ambulance button is used.

## Team details
Replace this section with your actual team number, names and roll numbers before submission.

| Member | Roll number | Contribution |
|---|---|---|
| Member 1 | Add roll no. | Ambulance and hospital data |
| Member 2 | Add roll no. | Emergency call registration |
| Member 3 | Add roll no. | Priority queue and nearest ambulance |
| Member 4 | Add roll no. | GUI and input validation |
| Member 5 | Add roll no. | File handling, testing and report |
