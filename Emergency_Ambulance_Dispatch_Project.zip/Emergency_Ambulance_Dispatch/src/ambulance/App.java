package ambulance;

import ambulance.service.DispatchCenter;
import ambulance.ui.MainFrame;
import javax.swing.SwingUtilities;

public class App {
    public static void main(String[] args) {
        DispatchCenter center = new DispatchCenter();
        center.startMonitor();
        SwingUtilities.invokeLater(() -> new MainFrame(center).setVisible(true));
    }
}
