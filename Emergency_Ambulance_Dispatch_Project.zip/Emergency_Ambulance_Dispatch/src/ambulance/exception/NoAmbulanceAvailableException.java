package ambulance.exception;

public class NoAmbulanceAvailableException extends Exception {
    public NoAmbulanceAvailableException(String message) {
        super(message);
    }
}
