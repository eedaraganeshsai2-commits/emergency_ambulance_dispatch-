package ambulance.model;

public class Ambulance {
    private final String id;
    private final Location location;
    private boolean available;

    public Ambulance(String id, Location location) {
        this.id = id;
        this.location = location;
        this.available = true;
    }

    public String getId() { return id; }
    public Location getLocation() { return location; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return id + " at " + location + (available ? " [FREE]" : " [BUSY]");
    }
}
