package ambulance.model;

public class EmergencyCall {
    private final String patientName;
    private final Location location;
    private final int severity; // 1 = low, 5 = critical
    private String assignedAmbulance = "Not assigned";

    public EmergencyCall(String patientName, Location location, int severity) {
        this.patientName = patientName;
        this.location = location;
        this.severity = severity;
    }

    public String getPatientName() { return patientName; }
    public Location getLocation() { return location; }
    public int getSeverity() { return severity; }
    public String getAssignedAmbulance() { return assignedAmbulance; }
    public void setAssignedAmbulance(String id) { assignedAmbulance = id; }

    @Override
    public String toString() {
        return "Patient: " + patientName + " | Severity: " + severity +
               " | Location: " + location + " | Ambulance: " + assignedAmbulance;
    }
}
