package ambulance.model;

public class Hospital {
    private final String name;
    private final Location location;

    public Hospital(String name, Location location) {
        this.name = name;
        this.location = location;
    }

    public String getName() { return name; }
    public Location getLocation() { return location; }
}
