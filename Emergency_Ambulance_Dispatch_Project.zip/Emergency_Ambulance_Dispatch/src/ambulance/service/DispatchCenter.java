package ambulance.service;

import ambulance.model.*;
import ambulance.exception.NoAmbulanceAvailableException;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class DispatchCenter {
    private final ArrayList<Ambulance> ambulances = new ArrayList<>();
    private final HashMap<String, Hospital> hospitals = new HashMap<>();
    private final PriorityQueue<EmergencyCall> calls =
        new PriorityQueue<>((a, b) -> Integer.compare(b.getSeverity(), a.getSeverity()));
    private final ArrayList<EmergencyCall> history = new ArrayList<>();
    private final String dataFile = "data/dispatch_history.csv";

    public DispatchCenter() {
        ambulances.add(new Ambulance("AMB-101", new Location(1, 2)));
        ambulances.add(new Ambulance("AMB-102", new Location(5, 4)));
        ambulances.add(new Ambulance("AMB-103", new Location(8, 1)));
        ambulances.add(new Ambulance("AMB-104", new Location(3, 7)));
        ambulances.add(new Ambulance("AMB-105", new Location(9, 6)));
        hospitals.put("City Hospital", new Hospital("City Hospital", new Location(2, 3)));
        hospitals.put("Care Hospital", new Hospital("Care Hospital", new Location(7, 5)));
        loadHistory();
    }

    public synchronized String dispatch(String patient, double x, double y, int severity)
            throws NoAmbulanceAvailableException {
        if (patient == null || patient.trim().isEmpty())
            throw new IllegalArgumentException("Patient name cannot be empty.");
        if (severity < 1 || severity > 5)
            throw new IllegalArgumentException("Severity must be between 1 and 5.");

        EmergencyCall call = new EmergencyCall(patient.trim(), new Location(x, y), severity);
        calls.offer(call);
        EmergencyCall next = calls.poll(); // highest severity is selected first
        Ambulance nearest = null;
        double bestDistance = Double.MAX_VALUE;

        for (Ambulance a : ambulances) {
            if (a.isAvailable()) {
                double d = a.getLocation().distanceTo(next.getLocation());
                if (d < bestDistance) {
                    bestDistance = d;
                    nearest = a;
                }
            }
        }

        if (nearest == null) {
            history.add(next);
            saveHistory(next);
            throw new NoAmbulanceAvailableException("No free ambulance is available. Call saved in history.");
        }

        nearest.setAvailable(false);
        next.setAssignedAmbulance(nearest.getId());
        history.add(next);
        saveHistory(next);
        return "DISPATCH SUCCESSFUL\n" + next + "\nDistance: " +
               String.format("%.2f", bestDistance) + " units\nNearest hospital: " +
               nearestHospital(next.getLocation());
    }

    private String nearestHospital(Location loc) {
        String result = "Not available";
        double best = Double.MAX_VALUE;
        for (Hospital h : hospitals.values()) {
            double d = loc.distanceTo(h.getLocation());
            if (d < best) { best = d; result = h.getName(); }
        }
        return result;
    }

    public synchronized String getStatusReport() {
        StringBuilder sb = new StringBuilder("AMBULANCE STATUS REPORT\n");
        Iterator<Ambulance> iterator = ambulances.iterator();
        while (iterator.hasNext()) sb.append(iterator.next()).append("\n");
        sb.append("\nRecent dispatch history:\n");
        for (EmergencyCall c : history) sb.append(c).append("\n");
        return sb.toString();
    }

    public synchronized void releaseAmbulance(String id) {
        for (Ambulance a : ambulances)
            if (a.getId().equalsIgnoreCase(id)) a.setAvailable(true);
    }

    private void saveHistory(EmergencyCall call) {
        try {
            Path path = Paths.get(dataFile);
            Files.createDirectories(path.getParent());
            boolean newFile = !Files.exists(path);
            try (BufferedWriter writer = Files.newBufferedWriter(path,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
                if (newFile) writer.write("patient,severity,x,y,ambulance");
                if (newFile) writer.newLine();
                writer.write(call.getPatientName().replace(",", " ") + "," +
                    call.getSeverity() + "," + call.getLocation().getX() + "," +
                    call.getLocation().getY() + "," + call.getAssignedAmbulance());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Could not save history: " + e.getMessage());
        }
    }

    private void loadHistory() {
        Path path = Paths.get(dataFile);
        if (!Files.exists(path)) return;
        try (BufferedReader reader = Files.newBufferedReader(path)) {
            String line;
            reader.readLine(); // header
            while ((line = reader.readLine()) != null) {
                String[] p = line.split(",");
                if (p.length >= 5) {
                    EmergencyCall c = new EmergencyCall(p[0],
                        new Location(Double.parseDouble(p[2]), Double.parseDouble(p[3])),
                        Integer.parseInt(p[1]));
                    c.setAssignedAmbulance(p[4]);
                    history.add(c);
                }
            }
        } catch (Exception e) {
            System.err.println("History file could not be loaded: " + e.getMessage());
        }
    }

    // Simple background monitor thread used to demonstrate multithreading.
    public void startMonitor() {
        Thread monitor = new Thread(() -> {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    Thread.sleep(30000);
                    System.out.println("[Monitor] Dispatch system is running.");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        monitor.setDaemon(true);
        monitor.start();
    }
}
