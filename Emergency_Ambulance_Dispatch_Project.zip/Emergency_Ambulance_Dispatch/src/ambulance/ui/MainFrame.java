package ambulance.ui;

import ambulance.service.DispatchCenter;
import ambulance.exception.NoAmbulanceAvailableException;
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private final DispatchCenter center;
    private final JTextField patientField = new JTextField(15);
    private final JTextField xField = new JTextField("4", 5);
    private final JTextField yField = new JTextField("3", 5);
    private final JComboBox<Integer> severityBox = new JComboBox<>(new Integer[]{1,2,3,4,5});
    private final JTextArea output = new JTextArea(17, 55);

    public MainFrame(DispatchCenter center) {
        super("Emergency Ambulance Dispatch System");
        this.center = center;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JLabel heading = new JLabel("EMERGENCY AMBULANCE DISPATCH", SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 20));
        add(heading, BorderLayout.NORTH);

        JPanel form = new JPanel(new FlowLayout());
        form.add(new JLabel("Patient:"));
        form.add(patientField);
        form.add(new JLabel("X:"));
        form.add(xField);
        form.add(new JLabel("Y:"));
        form.add(yField);
        form.add(new JLabel("Severity (1-5):"));
        form.add(severityBox);

        JButton dispatchButton = new JButton("Dispatch Ambulance");
        JButton reportButton = new JButton("Show Status / History");
        JButton releaseButton = new JButton("Release Ambulance");
        form.add(dispatchButton);
        form.add(reportButton);
        form.add(releaseButton);
        add(form, BorderLayout.CENTER);

        output.setEditable(false);
        output.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        add(new JScrollPane(output), BorderLayout.SOUTH);

        dispatchButton.addActionListener(e -> dispatch());
        reportButton.addActionListener(e -> output.setText(center.getStatusReport()));
        releaseButton.addActionListener(e -> {
            String id = JOptionPane.showInputDialog(this, "Enter ambulance ID (e.g. AMB-101):");
            if (id != null && !id.trim().isEmpty()) {
                center.releaseAmbulance(id.trim());
                output.setText("If the ID exists, the ambulance has been marked FREE.\n\n" +
                               center.getStatusReport());
            }
        });

        pack();
        setLocationRelativeTo(null);
    }

    private void dispatch() {
        try {
            String patient = patientField.getText();
            double x = Double.parseDouble(xField.getText());
            double y = Double.parseDouble(yField.getText());
            int severity = (Integer) severityBox.getSelectedItem();
            output.setText(center.dispatch(patient, x, y, severity));
        } catch (NumberFormatException ex) {
            output.setText("Please enter valid numeric X and Y coordinates.");
        } catch (NoAmbulanceAvailableException | IllegalArgumentException ex) {
            output.setText("ERROR: " + ex.getMessage());
        } finally {
            // finally demonstrates reliable completion of input handling.
            patientField.requestFocusInWindow();
        }
    }
}
